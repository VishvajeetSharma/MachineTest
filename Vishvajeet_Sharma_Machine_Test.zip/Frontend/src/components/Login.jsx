import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useNavigate } from "react-router-dom";
import { userLoginService } from "../services/user.service.js";
import { showAlert } from "../utils/showAlert.js";
import { storeData } from "../utils/manageData.js";
import { useContext } from "react";
import { AuthContext } from "../context/auth.context.jsx";

const schema = yup.object().shape({
  email: yup
    .string()
    .required("Email is required")
    .email("Please enter a valid email address"),

  password: yup
    .string()
    .required("Password is required")
    .matches(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,15}$/,
      "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character (@$!%*?&), and be 6-15 characters long",
    ),
});

const Login = () => {
  const navigate = useNavigate();
  const { setToken } = useContext(AuthContext);
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: yupResolver(schema),
  });

  const onSubmit = async (data) => {
    try {
      const res = await userLoginService(data);
      if (res.success) {
        storeData("token", res?.data?.token);
        setToken(res?.data?.token);
        reset();
        navigate("/view-task");
      } else {
        showAlert("User Login", res?.message, "error");
      }
    } catch (err) {
      showAlert("User Login", "Internal Server Error", "error");
    }
  };
  return (
    <>
      <div className="row align-items-center my-3">
        <div className="col-sm-10 mx-auto">
          <div className="row">
            {/* Left side image */}
            <div className="col-lg-6 text-center mt-lg-0">
              <img
                src="img/pic3.jpeg"
                alt="illustration"
                className="img-fluid access-img"
              />
            </div>

            {/* Right side input  */}
            <div className="col-lg-6 col-10 mx-auto m-5 p-5  bg-white text-dark">
              <h1 className="access-title fw-bold mb-4">
                <span className="text-purple">Login</span> <span className="text-orange">Here!</span>
              </h1>

              {/* INPUT */}
              <form onSubmit={handleSubmit(onSubmit)}>
                <div className="mb-4">
                  <input
                    type="email"
                    {...register("email")}
                    className="form-control custom-input"
                    placeholder="Enter your email"
                  />
                  {errors.email && (
                    <small className="text-danger">
                      {errors.email.message}
                    </small>
                  )}
                </div>

                <div className="mb-4">
                  <input
                    type="password"
                    {...register("password")}
                    className="form-control custom-input"
                    placeholder="Enter your password"
                  />
                  {errors.password && (
                    <small className="text-danger">
                      {errors.password.message}
                    </small>
                  )}
                </div>

                <button className="btn bg-purple w-100 py-2 mt-4 fw-bold">
                  Login
                </button>
                <div className="mt-3 text-start">
                  <small className="text-muted fw-bold">
                    Not have an account <a href="/register" className="text-orange text-decoration-none">Register Here</a>
                  </small>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
